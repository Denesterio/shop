<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link rel="stylesheet" href='/css/app.css'>

    </head>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <body class="antialiased">
        <div id="app">
            <div class="container-xl mt-3">
                <div class="row">
                    <b-col cols="3">
                        <left-menu-component
                            :categories='<?php echo e($categories); ?>'
                            :subcategories='<?php echo e($subcategories); ?>'
                        ></left-menu-component>
                        </b-col>
                    <b-col cols="9">
                        <product-list-component
                            :products='<?php echo e($products); ?>'>
                        </product-list-component>
                    </b-col>
                </div>
            </div>
        </div>
    <script src='/js/app.js'></script>
    </body>
</html>
<?php /**PATH /home/mrdns/php/shop/resources/views/categoryProducts.blade.php ENDPATH**/ ?>