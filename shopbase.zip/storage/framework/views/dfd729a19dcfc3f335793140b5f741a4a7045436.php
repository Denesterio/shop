<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href='css/app.css'>
</head>
<body>
    <div id='app'>
        <subcategories-component
            title='Список подкатегорий'
           
        />
    </div>
    <script src='js/app.js'></script>
</body>
</html><?php /**PATH /home/mrdns/php/shop/resources/views/subcategories.blade.php ENDPATH**/ ?>