<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href='css/app.css'>
</head>
<body>
    <div id='app'>
        <?php if(count($categories)): ?>
            <ul>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($category['title']); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <em>Категории отсутствуют</em>
        <?php endif; ?>

        <categories-component
            title='Список кагеорий!'
            :categories='<?php echo e($categories); ?>'
        />
    </div>
    <script src='js/app.js'></script>
</body>
</html><?php /**PATH C:\Users\R.Mingalieva\Documents\shop\resources\views/categories.blade.php ENDPATH**/ ?>