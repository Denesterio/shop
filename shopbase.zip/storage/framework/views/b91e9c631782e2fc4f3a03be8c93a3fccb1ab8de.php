<header style="height: 60px; background-color: blue">
    <div class="container-xl">
        <div class="row">
            <div class="col-md-3 p-2" style="height: inherit">LOGO</div>
            <div class="col-md-6 p-2" style="height: inherit">SEARCH</div>
            <div class="col-md-3 p-2" style="height: inherit">LOGIN</div>
        </div>
    </div>
</header>
<?php /**PATH /home/mrdns/php/shop/resources/views/layouts/header.blade.php ENDPATH**/ ?>