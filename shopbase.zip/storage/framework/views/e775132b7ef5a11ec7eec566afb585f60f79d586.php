<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Список продуктов</title>
    <link rel="stylesheet" href='css/app.css'>
</head>
<body>
    <div id='app'>
        <products-component></products-component>
    </div>
    <script src='js/app.js'></script>
</body>
</html><?php /**PATH /home/mrdns/php/shop/resources/views/products.blade.php ENDPATH**/ ?>